#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Interfaces for virtual reality related hardware drivers."""
